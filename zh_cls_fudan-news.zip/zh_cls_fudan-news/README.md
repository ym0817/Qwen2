---
tasks:
- text-generation
- chat
license: Apache License 2.0
#用户自定义标签
tags:
- text-classification
- text-generation
- chat
- zh
---
### Clone with HTTP
```bash
git clone https://www.modelscope.cn/datasets/damo/zh_cls_fudan-news.git
```

关联模型: https://www.modelscope.cn/models/damo/nlp_seqgpt-560m/summary


下载: 
```python
dataset = MsDataset.load('damo/zh_cls_fudan-news').to_hf_dataset()
```

